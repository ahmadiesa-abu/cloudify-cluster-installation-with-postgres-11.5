sudo yum install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-7-x86_64/pgdg-redhat-repo-latest.noarch.rpm
sudo yum install --downloadonly --downloaddir=/opt/cloudify/sources/ postgresql11-libs.x86_64
sudo yum install --downloadonly --downloaddir=/opt/cloudify/sources/ postgresql11.x86_64
sudo yum install --downloadonly --downloaddir=/opt/cloudify/sources/ postgresql11-contrib.x86_64
sudo yum install --downloadonly --downloaddir=/opt/cloudify/sources/ postgresql11-server.x86_64
sudo yum install --downloadonly --downloaddir=/opt/cloudify/sources/ postgresql11-devel.x86_64
sudo yum install --downloadonly --downloaddir=/opt/cloudify/sources/ postgresql11-plperl.x86_64
sudo yum install -y /opt/cloudify/sources/libicu-50.2-3.el7.x86_64.rpm
sudo yum install -y /opt/cloudify/sources/libicu-devel-50.2-3.el7.x86_64.rpm
sudo yum install -y /opt/cloudify/sources/postgresql11-plperl.x86_64
sudo yum install -y python3
sudo yum install -y wget
sudo yum install -y http://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/python36-psycopg2-2.7.7-1.el7.x86_64.rpm
sudo wget --output-document="/opt/cloudify/sources/python-psycopg2-2.7.7-1.el7.x86_64.rpm" http://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/python36-psycopg2-2.7.7-1.el7.x86_64.rpm
